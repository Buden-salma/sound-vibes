from django.shortcuts import render,redirect
from playlist.models import spotify
from playlist.models import singer

# Create your views here.
def homeview(request):
    obj=spotify.objects.all()
    return render(request,'home.html',{'res':obj})
def albumview(request):
    if request.method=='POST':
        a=request.POST.get('title')
        b=request.POST.get('rating')
        c=request.POST.get('album')
        d=request.POST.get('type1')
        e=request.POST.get('artist')
        if singer.objects.filter(name=e).exists():

            s=spotify.objects.get(artist=e)
            obj=spotify(title=a,rating=b,album=c,type=d,artist=s)
            obj.save()
        return redirect('homepage')
    return render(request,'album.html')
def singerview(request):
    if request.method=='POST':
        a=request.POST.get('name')
        b=request.POST.get('debut')
        c=request.POST.get('fanname')
        obj1=singer(name=a,debut=b,fanname=c)
        obj1.save()
        return redirect('homepage')
    return render(request,'singer.html')




