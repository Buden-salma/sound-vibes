from django.urls import path
from playlist import views

urlpatterns=[
    path('',views.homeview,name="homepage"),
    path('album',views.albumview,name="albumpage"),
    path('singer',views.singerview,name="singerpage"),

]