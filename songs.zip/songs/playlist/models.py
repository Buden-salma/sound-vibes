from django.db import models


# Create your models here.
class spotify(models.Model):
    title=models.CharField(max_length=30)
    rating=models.IntegerField()
    album=models.CharField(max_length=20)
    type1=models.CharField(max_length=20)
    artist=models.ForeignKey('singer',on_delete=models.CASCADE)


    def __str__(self):
        return self.title
class singer(models.Model):
    name=models.CharField(max_length=30)
    debut=models.IntegerField()
    fanname=models.IntegerField()


    def __str__(self):
        return self.fanname
    