from django.contrib import admin
from playlist.models import *

# Register your models here.
admin.site.register(spotify)
admin.site.register(singer)
